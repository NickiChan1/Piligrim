import React from 'react';

export default function MainHeader() {
    return (
        <header className="main__header navbar">
            <div className="main__header_content navbar-brand">
                <div className="main__header_logo">
                    <img alt="LOGO"/>
            </div>
                    <div className="main__header_reg">
                        <button className="btn btn_enter">Войти</button>
                        <button className="btn btn_rega">Регистрация</button>
                    </div>
            </div>
        </header>
        
        );
    }