import React from "react";
export default function Manual(){
    return(
        <div>

        </div>
    );
}