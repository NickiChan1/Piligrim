import React from "react";
export default function News(){
    return(
        <div>
             <div className="page__info"><span className="text-center page__pointer">Новости</span></div>

<div className="container-fluid content_container">
        <div className="news__container">
{/* <!--Карточки новостей--> */}
            <div className="card " style={{width:"42rem"}}>
                <div className="card-header news__heaeder"><span className="news__name">Название новости</span></div>
                <img src="img/moto.png" className="card-img-top" alt="news_image"/>
                <div className="card-body">
                    <p className="card-text">
                        Lorem ipsum dolor sit amet,
                        consectetur adipisicing elit.
                        Ad alias aliquam at blanditiis error incidunt, laboriosam, magnam modi mollitia, odit perferendis porro quidem quod tempora ut.
                        Dolor eum modi quasi quidem repudiandae? Beatae consectetur cum dolor, fugit necessitatibus nihil quam velit?
                        Assumenda blanditiis corporis delectus deleniti dignissimos eius est exercitationem explicabo hic labore libero mollitia,
                        nam neque, nobis numquam officia, officiis quaerat quas quibusdam quidem quo repellendus sed similique sunt totam vel vero vitae.
                        Debitis dicta earum eos id iusto, laborum necessitatibus nemo officiis porro praesentium quo sed soluta temporibus totam voluptatum!
                        Assumenda dolorem eos illum mollitia similique sunt temporibus.
                    </p>
                </div>
                <div className="card-footer news__footer"><span className="news__date">01.06.2021</span></div>
            </div>

            <div className="card "style={{width:"42rem"}}>
                <div className="card-header news__heaeder"><span className="news__name">Название новости</span></div>
                <img src="img/moto.png" className="card-img-top" alt="news_image"/>
                <div className="card-body">
                    <p className="card-text">
                        Lorem ipsum dolor sit amet,
                        consectetur adipisicing elit.
                        Ad alias aliquam at blanditiis error incidunt, laboriosam, magnam modi mollitia, odit perferendis porro quidem quod tempora ut.
                        Dolor eum modi quasi quidem repudiandae? Beatae consectetur cum dolor, fugit necessitatibus nihil quam velit?
                        Assumenda blanditiis corporis delectus deleniti dignissimos eius est exercitationem explicabo hic labore libero mollitia,
                        nam neque, nobis numquam officia, officiis quaerat quas quibusdam quidem quo repellendus sed similique sunt totam vel vero vitae.
                        Debitis dicta earum eos id iusto, laborum necessitatibus nemo officiis porro praesentium quo sed soluta temporibus totam voluptatum!
                        Assumenda dolorem eos illum mollitia similique sunt temporibus.
                    </p>
                </div>
                <div className="card-footer news__footer"><span className="news__date">01.06.2021</span></div>
            </div>

        </div>
    </div>

<nav className="navbar fixed-bottom main__footer">
    <div className="main__footer_content">
        <span>Copyright: 2021-2022</span>
    </div>
</nav>
        </div>
    );
}