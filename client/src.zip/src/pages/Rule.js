import React from "react";
export default function Rule(){
    return(
        <div>

        </div>
    );
}