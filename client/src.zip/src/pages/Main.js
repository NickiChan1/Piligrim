import React from "react";
import { NavLink } from "react-router-dom";
import { REGISTRATION_ROUTE } from "../path/PathConst";
import moto from '../components/media/img/moto.png';

export default function Main(){
    return(
        <div>
            <div class="container">
            <div class="container__navigation">
{/* Карточки навигации */}
                <div class="card container__navigation_card" style={{width: "18rem"}}>
                    <img src={moto} alt="News"/>
                    <div class="card-body">
                        <NavLink to={REGISTRATION_ROUTE} class="card-text">Новости</NavLink>
                    </div>
                </div>

                <div class="card container__navigation_card" style={{width: "18rem"}}>
                    <img src={moto} alt="News"/>
                    <div class="card-body">
                        <NavLink to={REGISTRATION_ROUTE} class="card-text">Новости</NavLink>
                    </div>
                </div>

                <div class="card container__navigation_card" style={{width: "18rem"}}>
                    <img src={moto} alt="News"/>
                    <div class="card-body">
                        <NavLink to={REGISTRATION_ROUTE} class="card-text">Новости</NavLink>
                    </div>
                </div>

            </div>

            <div class="container__navigation">
                {/* <!--Карточки навигации--> */}
                <div class="card container__navigation_card" style={{width: "18rem"}}>
                    <img src={moto} alt="News"/>
                    <div class="card-body">
                        <NavLink to={REGISTRATION_ROUTE}  class="card-text">Новости</NavLink>
                    </div>
                </div>

                <div class="card container__navigation_card" style={{width: "18rem"}}>
                    <img src={moto} alt="News"/>
                    <div class="card-body">
                        <NavLink to={REGISTRATION_ROUTE} class="card-text">Новости</NavLink>
                    </div>
                </div>

                <div class="card container__navigation_card" style={{width: "18rem"}}>
                    <img src={moto} alt="News"/>
                    <div class="card-body">
                        <NavLink to={REGISTRATION_ROUTE} class="card-text">Новости</NavLink>
                    </div>
                </div>

            </div>
        </div>

<nav class="navbar  main__footer">
    <div class="main__footer_content">
        <span>Copyright: 2021-2022</span>
    </div>
</nav>
        </div>
    );
}