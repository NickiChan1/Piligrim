import React from "react";
export default function Club(){
    return(
        <div>
            <div class="page__info"><span class="text-center page__pointer">История клуба</span></div>

<div class="container-fluid">
    <div class="card club__rules">
        <div class="card-body">
            <p class="card-text">Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Adipisci aliquid architecto blanditiis commodi consequatur cumque,
                delectus distinctio dolores doloribus dolorum eius illum nobis obcaecati odio placeat provident quisquam repellendus,
                repudiandae sed sint sunt, ullam voluptatibus voluptatum.
                A adipisci aliquid aperiam, aspernatur autem commodi delectus dicta dolorem doloribus earum ex excepturi expedita harum id illum impedit iste iusto labore molestiae necessitatibus obcaecati odit pariatur placeat
                quasi quia quis quod ratione reiciendis sunt unde ut vel vero voluptatum.
                Ad animi autem blanditiis corporis, cumque debitis dolorum fugiat inventore libero nemo quisquam rerum similique sint unde velit? A ab alias asperiores at atque aut blanditiis consectetur deleniti distinctio eos hic incidunt, laborum libero maiores modi porro quas quisquam recusandae reiciendis reprehenderit rerum sapiente, tempora temporibus? Ad, cum expedita illum numquam perspiciatis possimus qui quo sunt ullam velit? Commodi doloremque maiores optio. Ducimus eaque quod sit? Accusamus consectetur consequuntur cum dignissimos dolores ex itaque iusto libero maxime molestiae nihil odio optio quo, reiciendis rerum sint sunt suscipit temporibus ut veritatis? Adipisci architecto beatae cupiditate dignissimos dolorem ex facere facilis ipsam molestiae nihil non, quasi quibusdam, quod tenetur totam. Debitis, dignissimos dolorem eaque harum incidunt modi molestias mollitia nisi,
                odit officiis quas quibusdam sed tempora!Lorem ipsum dolor sit amet,
                consectetur adipisicing elit.
                Adipisci aliquid architecto blanditiis commodi consequatur cumque,
                delectus distinctio dolores doloribus dolorum eius illum nobis obcaecati odio placeat provident quisquam repellendus,
                repudiandae sed sint sunt, ullam voluptatibus voluptatum.
                A adipisci aliquid aperiam, aspernatur autem commodi delectus dicta dolorem doloribus earum ex excepturi expedita harum id illum impedit iste iusto labore molestiae necessitatibus obcaecati odit pariatur placeat
                quasi quia quis quod ratione reiciendis sunt unde ut vel vero voluptatum.
                Ad animi autem blanditiis corporis, cumque debitis dolorum fugiat inventore libero nemo quisquam rerum similique sint unde velit? A ab alias asperiores at atque aut blanditiis consectetur deleniti distinctio eos hic incidunt, laborum libero maiores modi porro quas quisquam recusandae reiciendis reprehenderit rerum sapiente, tempora temporibus? Ad, cum expedita illum numquam perspiciatis possimus qui quo sunt ullam velit? Commodi doloremque maiores optio. Ducimus eaque quod sit? Accusamus consectetur consequuntur cum dignissimos dolores ex itaque iusto libero maxime molestiae nihil odio optio quo, reiciendis rerum sint sunt suscipit temporibus ut veritatis? Adipisci architecto beatae cupiditate dignissimos dolorem ex facere facilis ipsam molestiae nihil non, quasi quibusdam, quod tenetur totam. Debitis, dignissimos dolorem eaque harum incidunt modi molestias mollitia nisi,
                odit officiis quas quibusdam sed tempora!</p>
        </div>
    </div>
</div>
<nav class="navbar fixed-bottom media__footer">
<div class="main__footer_content">
    <span>Copyright: 2021-2022</span>
</div>
</nav>
        </div>
    );
}