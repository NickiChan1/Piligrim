import React from "react";
export default function Music(){
    return(
        <div>

        </div>
    );
}